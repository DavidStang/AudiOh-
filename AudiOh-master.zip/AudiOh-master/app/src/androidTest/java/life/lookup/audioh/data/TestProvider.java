package life.lookup.audioh.data;

import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.test.AndroidTestCase;

import junit.framework.Assert;

public class TestProvider extends AndroidTestCase {

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();

        mContext.deleteDatabase(AudioRecordingsDbHelper.DATABASE_NAME);
    }

    public void testProvider_InsertRecord() {
        // Arrange
        final long TEST_DATE = 1419033600L;  // December 20th, 2014
        final String TEST_FILE = mContext.getExternalFilesDir("recordings").toString() + "/file1.pcm";
        final double TEST_LAT = 64.7488;
        final double TEST_LONG = -147.353;
        final int TEST_DURATION = 123;

        ContentValues testRecord = new ContentValues();
        testRecord.put(AudioRecordings.Recording.FILE_PATH, TEST_FILE);
        testRecord.put(AudioRecordings.Recording.DATE, TEST_DATE);
        testRecord.put(AudioRecordings.Recording.COORD_LAT, TEST_LAT);
        testRecord.put(AudioRecordings.Recording.COORD_LONG, TEST_LONG);
        testRecord.put(AudioRecordings.Recording.DURATION, TEST_DURATION);

        // Act
        Uri target = mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord);

        // Assert
        Assert.assertEquals(1, ContentUris.parseId(target));
    }

    public void testProvider_InsertRecord_NoLocation() {
        // Arrange
        final long TEST_DATE = 1419033600L;  // December 20th, 2014
        final String TEST_FILE = mContext.getExternalFilesDir("recordings").toString() + "/file1.pcm";
        final int TEST_DURATION = 123;

        ContentValues testRecord = new ContentValues();
        testRecord.put(AudioRecordings.Recording.FILE_PATH, TEST_FILE);
        testRecord.put(AudioRecordings.Recording.DATE, TEST_DATE);
        testRecord.put(AudioRecordings.Recording.DURATION, TEST_DURATION);

        // Act
        Uri target = mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord);

        // Assert
        Assert.assertEquals(1, ContentUris.parseId(target));
    }

    public void testProvider_Query() {
        // Arrange
        final long TEST_DATE = 1419033600L;  // December 20th, 2014
        final String TEST_FILE = mContext.getExternalFilesDir("recordings").toString() + "/file1.pcm";
        final double TEST_LAT = 64.7488;
        final double TEST_LONG = -147.353;
        final int TEST_DURATION = 123;

        ContentValues testRecord = new ContentValues();
        testRecord.put(AudioRecordings.Recording.FILE_PATH, TEST_FILE);
        testRecord.put(AudioRecordings.Recording.DATE, TEST_DATE);
        testRecord.put(AudioRecordings.Recording.COORD_LAT, TEST_LAT);
        testRecord.put(AudioRecordings.Recording.COORD_LONG, TEST_LONG);
        testRecord.put(AudioRecordings.Recording.DURATION, TEST_DURATION);
        Uri target = mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord);

        // Act
        Cursor c = mContext.getContentResolver().query(target,
                new String[]{
                        AudioRecordings.Recording._ID,
                        AudioRecordings.Recording.FILE_PATH,
                        AudioRecordings.Recording.DATE,
                        AudioRecordings.Recording.COORD_LAT,
                        AudioRecordings.Recording.COORD_LONG,
                        AudioRecordings.Recording.DURATION
                }, null, null, null);

        // Assert
        c.moveToFirst();

        Assert.assertEquals(1, c.getInt(0));
        Assert.assertEquals(TEST_FILE, c.getString(1));
        Assert.assertEquals(TEST_DATE, c.getInt(2));
        Assert.assertEquals(TEST_LAT, c.getDouble(3));
        Assert.assertEquals(TEST_LONG, c.getDouble(4));
        Assert.assertEquals(TEST_DURATION, c.getInt(5));

        c.close();
    }

    public void testProvider_Delete_SingleItem() {
        // Arrange
        ContentValues testRecord1 = new ContentValues();
        testRecord1.put(AudioRecordings.Recording.FILE_PATH, "123");
        testRecord1.put(AudioRecordings.Recording.DATE, 123);
        testRecord1.put(AudioRecordings.Recording.DURATION, 1);
        mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord1);
        ContentValues testRecord2 = new ContentValues();
        testRecord2.put(AudioRecordings.Recording.FILE_PATH, "456");
        testRecord2.put(AudioRecordings.Recording.DATE, 123);
        testRecord2.put(AudioRecordings.Recording.DURATION, 1);
        Uri target = mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord2);

        // Act
        int result = mContext.getContentResolver().delete(target, null, null);

        // Assert
        Assert.assertEquals(1, result);
    }

    public void testProvider_Delete_MultipleItems() {
        // Arrange
        ContentValues testRecord1 = new ContentValues();
        testRecord1.put(AudioRecordings.Recording.FILE_PATH, "123");
        testRecord1.put(AudioRecordings.Recording.DATE, 123);
        testRecord1.put(AudioRecordings.Recording.DURATION, 1);
        mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord1);
        ContentValues testRecord2 = new ContentValues();
        testRecord2.put(AudioRecordings.Recording.FILE_PATH, "456");
        testRecord2.put(AudioRecordings.Recording.DATE, 123);
        testRecord2.put(AudioRecordings.Recording.DURATION, 1);
        mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord2);

        // Act
        int result = mContext.getContentResolver().delete(AudioRecordings.Recording.CONTENT_URI, null, null);

        // Assert
        Assert.assertEquals(2, result);
    }

    public void testProvider_Update_SingleItem() {
        // Arrange
        ContentValues testRecord1 = new ContentValues();
        testRecord1.put(AudioRecordings.Recording.FILE_PATH, "123");
        testRecord1.put(AudioRecordings.Recording.DATE, 123);
        testRecord1.put(AudioRecordings.Recording.DURATION, 1);
        mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord1);
        ContentValues testRecord2 = new ContentValues();
        testRecord2.put(AudioRecordings.Recording.FILE_PATH, "456");
        testRecord2.put(AudioRecordings.Recording.DATE, 123);
        testRecord2.put(AudioRecordings.Recording.DURATION, 1);
        Uri target = mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord2);

        ContentValues updatedRecord = new ContentValues();
        updatedRecord.put(AudioRecordings.Recording.COORD_LAT, 12);

        // Act
        int result = mContext.getContentResolver().update(target, updatedRecord, null, null);

        // Assert
        Assert.assertEquals(1, result);
    }

    public void testProvider_Update_MultipleItems() {
        // Arrange
        ContentValues testRecord1 = new ContentValues();
        testRecord1.put(AudioRecordings.Recording.FILE_PATH, "123");
        testRecord1.put(AudioRecordings.Recording.DATE, 123);
        testRecord1.put(AudioRecordings.Recording.DURATION, 1);
        mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord1);
        ContentValues testRecord2 = new ContentValues();
        testRecord2.put(AudioRecordings.Recording.FILE_PATH, "456");
        testRecord2.put(AudioRecordings.Recording.DATE, 123);
        testRecord2.put(AudioRecordings.Recording.DURATION, 1);
        mContext.getContentResolver().insert(AudioRecordings.Recording.CONTENT_URI, testRecord2);

        ContentValues updatedRecord = new ContentValues();
        updatedRecord.put(AudioRecordings.Recording.COORD_LAT, 12);

        // Act
        int result = mContext.getContentResolver().update(AudioRecordings.Recording.CONTENT_URI, updatedRecord, null, null);

        // Assert
        Assert.assertEquals(2, result);
    }
}
