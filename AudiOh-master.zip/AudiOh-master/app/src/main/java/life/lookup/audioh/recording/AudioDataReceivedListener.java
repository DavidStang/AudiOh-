package life.lookup.audioh.recording;

public interface AudioDataReceivedListener {
    void onAudioDataReceived(short[] data);
}
