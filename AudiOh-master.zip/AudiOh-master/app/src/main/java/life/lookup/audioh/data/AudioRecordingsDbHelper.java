package life.lookup.audioh.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

class AudioRecordingsDbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    static final String DATABASE_NAME = "recordings.db";

    public AudioRecordingsDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_RECORDINGS_TABLE = new StringBuilder().append("CREATE TABLE ")
                .append(AudioRecordings.Recording.TABLE_NAME).append(" (")
                .append(AudioRecordings.Recording._ID).append(" INTEGER PRIMARY KEY AUTOINCREMENT,")
                .append(AudioRecordings.Recording.FILE_PATH).append(" TEXT UNIQUE NOT NULL, ")
                .append(AudioRecordings.Recording.DATE).append(" INTEGER NOT NULL, ")
                .append(AudioRecordings.Recording.COORD_LAT).append(" REAL, ")
                .append(AudioRecordings.Recording.COORD_LONG).append(" REAL, ")
                .append(AudioRecordings.Recording.DURATION).append(" INTEGER NOT NULL, ")
                .append(AudioRecordings.Recording.UPLOADED).append(" INTEGER, ")

                .append("UNIQUE (").append(AudioRecordings.Recording.FILE_PATH)
                .append(") ON CONFLICT IGNORE").append(" );").toString();

        db.execSQL(SQL_CREATE_RECORDINGS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + AudioRecordings.Recording.TABLE_NAME);
        onCreate(db);
    }
}
