package life.lookup.audioh.utils;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public final class Utils {
    private static final String EMAIL_KEY = "pref_user_email";
    private static final String VCARD_UPLOADED = "pref_vcardUploaded";
    private static final String WELCOME_SHOWN = "pref_welcomeShown";
    public static final String PREFS_FILE = "prefs";

    public static void saveUserEmail(Context ctx, String email) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(EMAIL_KEY, email);
        editor.apply();
    }

    public static String getUserEmail(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE);
        return prefs.getString(EMAIL_KEY, null);
    }

    public static void saveUserVcardUploaded(Activity activity, boolean value) {
        SharedPreferences prefs = activity.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(VCARD_UPLOADED, value);
        editor.apply();
    }

    public static boolean isUserVcardUploaded(Activity activity) {
        SharedPreferences prefs = activity.getPreferences(Context.MODE_PRIVATE);
        return prefs.getBoolean(VCARD_UPLOADED, false);
    }

    public static boolean isWelcomeScreenShown(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE);
        return prefs.getBoolean(WELCOME_SHOWN, false);
    }

    public static void saveWelcomeScreenShown(Context ctx, boolean value) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(WELCOME_SHOWN, value);
        editor.apply();
    }
}
