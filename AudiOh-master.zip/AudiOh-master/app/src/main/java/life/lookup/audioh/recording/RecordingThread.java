package life.lookup.audioh.recording;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.util.Log;

import java.util.concurrent.BlockingQueue;

public class RecordingThread extends AudioThreadBase {
    private int mSampleRateInHz, mChannelConfig, mAudioFormat;
    private boolean mShouldContinue = true;

    private final String LOG_TAG = RecordingThread.class.getSimpleName();

    public RecordingThread(Context context, BlockingQueue<short[]> data, int sampleRateInHz, int channelConfig, int audioFormat, AudioThreadStatusListener listener) {
        super(context, data, listener);
        mSampleRateInHz = sampleRateInHz;
        mChannelConfig = channelConfig;
        mAudioFormat = audioFormat;
    }

    @Override
    public void run() {
        Log.v(LOG_TAG, "Start");
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);

        int bufferSize = AudioRecord.getMinBufferSize(mSampleRateInHz, mChannelConfig,
                mAudioFormat);
        if (bufferSize == AudioRecord.ERROR || bufferSize == AudioRecord.ERROR_BAD_VALUE) {
            bufferSize = mSampleRateInHz * (mChannelConfig == AudioFormat.CHANNEL_IN_MONO ? 1 : 2) * 2;
        }
        short[] audioBuffer = new short[bufferSize / 2];
        AudioRecord record = new AudioRecord(MediaRecorder.AudioSource.DEFAULT, mSampleRateInHz,
                mChannelConfig, mAudioFormat, bufferSize);
        if (record.getState() != AudioRecord.STATE_INITIALIZED) {
            Log.e(LOG_TAG, "Audio Record can't initialize!");
            onFailure("Can't record audio");
            return;
        }
        record.startRecording();

        Log.v(LOG_TAG, "Start recording");

        onStarted();

        long shortsRead = 0;
        while (mShouldContinue) {
            int numberOfShort = record.read(audioBuffer, 0, bufferSize / 2);
            shortsRead += numberOfShort;

            // Notify encoding thread
            try {
                if (numberOfShort == bufferSize / 2) {
                    mQueue.put(audioBuffer);
                } else {
                    short[] finalArray = new short[numberOfShort];
                    System.arraycopy(audioBuffer, 0, finalArray, 0, numberOfShort);
                    mQueue.put(finalArray);
                }
            } catch (InterruptedException e) {
                Log.e(LOG_TAG, e.getMessage(), e);
            }
        }

        record.stop();
        record.release();

        Log.v(LOG_TAG, String.format("Recording stopped. Samples read: %d", shortsRead));

        // Set marker bit
        Log.v(LOG_TAG, "Signal queue");
        try {
            mQueue.put(MARKER_BIT);
        } catch (InterruptedException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
        }

        onCompleted();
    }

    public void stop() {
        mShouldContinue = false;
    }
}
