package life.lookup.audioh.utils;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;

public class ContentProviderUtils {
    public static int queryNumEntries(ContentResolver resolver, Uri uri) {
        Cursor cursor = resolver.query(uri, new String[]{"count(*)"}, null, null, null);
        if (cursor.getCount() == 0) {
            cursor.close();
            return 0;
        } else {
            cursor.moveToFirst();
            int result = cursor.getInt(0);
            cursor.close();
            return result;
        }
    }
}
