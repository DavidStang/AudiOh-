package life.lookup.audioh.recording;

import android.content.Context;
import android.os.Handler;

import java.util.concurrent.BlockingQueue;

abstract class AudioThreadBase implements Runnable {
    protected static final short[] MARKER_BIT = new short[]{-1};

    final BlockingQueue<short[]> mQueue;
    private AudioThreadStatusListener mListener;
    private Context mContext;
    private Handler mHandler;

    public AudioThreadBase(Context context, BlockingQueue<short[]> data, AudioThreadStatusListener listener) {
        mContext = context;
        mQueue = data;
        mListener = listener;
        mHandler = new Handler(context.getMainLooper());
    }

    Context getContext() {
        return mContext;
    }

    protected void onStarted() {
        if (mListener != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onStarted();
                }
            });
        }
    }

    protected void onFailure(final String reason, final Exception error) {
        if (mListener != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onFailure(reason, error);
                }
            });
        }
    }

    protected void onFailure(String reason) {
        onFailure(reason, null);
    }

    protected void onCompleted() {
        if (mListener != null) {
            mHandler.post(new Runnable() {
                @Override
                public void run() {
                    mListener.onCompleted();
                }
            });
        }
    }
}
