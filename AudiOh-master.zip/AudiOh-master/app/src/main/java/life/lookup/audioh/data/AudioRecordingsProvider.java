package life.lookup.audioh.data;

import android.annotation.TargetApi;
import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.File;
import java.io.FileNotFoundException;

public class AudioRecordingsProvider extends ContentProvider {
    private static final String LOG_TAG = AudioRecordingsProvider.class.getSimpleName();
    private static final UriMatcher sUriMatcher = buildUriMatcher();
    private static final int RECORDINGS = 1;
    private static final int RECORDINGS_ID = 2;
    private AudioRecordingsDbHelper mDbHelper;

    @Override
    public boolean onCreate() {
        mDbHelper = new AudioRecordingsDbHelper(getContext());
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (sUriMatcher.match(uri) == RECORDINGS_ID) {
            return openFileHelper(uri, mode);
        }
        throw new IllegalArgumentException("Unknown URI " + uri);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Cursor result;
        switch (sUriMatcher.match(uri)) {
            case RECORDINGS :
            {
                SQLiteDatabase db = mDbHelper.getReadableDatabase();
                result = db.query(AudioRecordings.Recording.TABLE_NAME,
                        projection, selection, selectionArgs, null, null, sortOrder);
                break;
            }
            case RECORDINGS_ID :
            {
                long id = ContentUris.parseId(uri);
                SQLiteDatabase db = mDbHelper.getReadableDatabase();
                result = db.query(AudioRecordings.Recording.TABLE_NAME,
                        projection, AudioRecordings.Recording._ID + "=?",
                        new String[]{String.valueOf(id)}, null, null, sortOrder);
                break;
            }
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        result.setNotificationUri(getContext().getContentResolver(), uri);
        return result;
    }

    @Override
    public String getType(Uri uri) {
        switch (sUriMatcher.match(uri)) {
            case RECORDINGS :
                return AudioRecordings.Recording.CONTENT_TYPE;
            case RECORDINGS_ID :
                return AudioRecordings.Recording.CONTENT_ITEM_TYPE;
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        Uri returnUri;
        if (sUriMatcher.match(uri) == RECORDINGS) {
            SQLiteDatabase db = mDbHelper.getWritableDatabase();
            long rowId = 0;
            try {
                rowId = db.insertOrThrow(AudioRecordings.Recording.TABLE_NAME, null, values);
            } finally {
                db.close();
            }
            if (rowId != -1) {
                returnUri = ContentUris.withAppendedId(AudioRecordings.Recording.CONTENT_URI, rowId);
            } else {
                throw new SQLException("Failed to insert row into " + uri);
            }
        } else {
            throw new UnsupportedOperationException("Unknown uri: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return returnUri;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int result;
        switch (sUriMatcher.match(uri)) {
            case RECORDINGS : {
                SQLiteDatabase db = mDbHelper.getWritableDatabase();
                Cursor c = db.query(AudioRecordings.Recording.TABLE_NAME,
                        new String[]{AudioRecordings.Recording.FILE_PATH},
                        selection, selectionArgs, null, null, null);
                deleteAudioFiles(c);

                result = db.delete(AudioRecordings.Recording.TABLE_NAME,
                        selection, selectionArgs);
                db.close();
                break;
            }
            case RECORDINGS_ID :
            {
                long id = ContentUris.parseId(uri);
                selection = AudioRecordings.Recording._ID + "=?";
                selectionArgs = new String[]{String.valueOf(id)};
                SQLiteDatabase db = mDbHelper.getWritableDatabase();
                Cursor c = db.query(AudioRecordings.Recording.TABLE_NAME,
                        new String[]{AudioRecordings.Recording.FILE_PATH},
                        selection, selectionArgs, null, null, null);
                deleteAudioFiles(c);

                result = db.delete(AudioRecordings.Recording.TABLE_NAME,
                        selection, selectionArgs);
                db.close();
                break;
            }
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if (result > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return result;
    }

    private void deleteAudioFiles(Cursor c)
    {
        while (c.moveToNext()) {
            String filePath = c.getString(0);
            File file = new File(filePath);
            boolean result = file.delete();
            Log.v(LOG_TAG, "File " + filePath + (result ? " deleted" : " not deleted"));
        }
        c.close();
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        int result;
        switch (sUriMatcher.match(uri)) {
            case RECORDINGS :
            {
                SQLiteDatabase db = mDbHelper.getWritableDatabase();
                result = db.update(AudioRecordings.Recording.TABLE_NAME, values,
                        selection, selectionArgs);
                db.close();
                break;
            }
            case RECORDINGS_ID :
            {
                long id = ContentUris.parseId(uri);
                SQLiteDatabase db = mDbHelper.getWritableDatabase();
                result = db.update(AudioRecordings.Recording.TABLE_NAME, values,
                        AudioRecordings.Recording._ID + "=?",
                        new String[]{String.valueOf(id)});
                db.close();
                break;
            }
            default:
                throw new IllegalArgumentException("Unknown URI " + uri);
        }
        if (result > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return result;
    }

    @Override
    @TargetApi(11)
    public void shutdown() {
        mDbHelper.close();
        super.shutdown();
    }

    static UriMatcher buildUriMatcher() {
        UriMatcher matcher = new UriMatcher(UriMatcher.NO_MATCH);
        matcher.addURI(AudioRecordings.AUTHORITY, AudioRecordings.PATH_AUDIO_RECORDINGS, RECORDINGS);
        matcher.addURI(AudioRecordings.AUTHORITY, AudioRecordings.PATH_AUDIO_RECORDINGS + "/#", RECORDINGS_ID);
        return matcher;
    }
}
