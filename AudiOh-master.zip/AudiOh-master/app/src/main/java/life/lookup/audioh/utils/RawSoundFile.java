package life.lookup.audioh.utils;

import android.media.AudioFormat;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;

public class RawSoundFile {
    public static final int SAMPLING_RATE = 44100;
    public static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;

    private int mSampleRate;
    private int mAudioFormat;
    private int mChannels;
    private int mNumSamples;
    private ShortBuffer mDecodedSamples;
    private int mNumFrames;
    private int mLength;

    private RawSoundFile() {
        mChannels = 1;
        mSampleRate = SAMPLING_RATE;
        mAudioFormat = AUDIO_FORMAT;
    }

    public static RawSoundFile openStream(InputStream stream)
            throws java.io.IOException {
        RawSoundFile soundFile = new RawSoundFile();
        byte[] data = IOUtils.toByteArray(stream);
        soundFile.readRawData(ByteBuffer.wrap(data).asShortBuffer(), data.length / 2);
        return soundFile;
    }

    // Sample rate in Hz
    public int getSampleRate() {
        return mSampleRate;
    }

    public int getAudioFormat() {
        return mAudioFormat;
    }

    public int getChannelsCount() {
        return mChannels;
    }

    public int getNumSamples() {
        return mNumSamples;
    }

    public int getNumFrames() {
        return mNumFrames;
    }

    // Length in milliseconds
    public int getLength() {
        return mLength;
    }

    public ShortBuffer getSamples() {
        if (mDecodedSamples != null) {
            return mDecodedSamples.asReadOnlyBuffer();
        } else {
            return null;
        }
    }

    private void readRawData(ShortBuffer decodedSamples, int size) {
        mNumSamples = size;
        decodedSamples.rewind();
        mDecodedSamples = decodedSamples;
        mNumFrames = mNumSamples * mChannels;
        mLength = AudioUtils.getAudioLength(mNumSamples, mSampleRate);
    }
}
