package life.lookup.audioh;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import life.lookup.audioh.data.AudioRecordings;

public class EditActivity extends AppCompatActivity {

    private Uri mRecordingUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        mRecordingUri = intent.getParcelableExtra(PlaybackFragment.ARG_RECORDING_URI);

        if (findViewById(R.id.editorFragmentPlaceholder) != null) {
            if (savedInstanceState != null)
                return;

            PlaybackFragment fragment = PlaybackFragment.createInstance(mRecordingUri);

            getSupportFragmentManager().beginTransaction()
                    .add(R.id.editorFragmentPlaceholder, fragment)
                    .commit();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        else if (id == R.id.action_delete) {
            deleteRecord();
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void deleteRecord() {
        ContentResolver resolver = getContentResolver();
        Cursor c = resolver.query(mRecordingUri, new String[]{AudioRecordings.Recording.FILE_PATH},
                null, null, null);
        c.moveToFirst();
        String filepath = c.getString(0);
        c.close();
        filepath = Uri.parse(filepath).getLastPathSegment();
        resolver.delete(mRecordingUri, null, null);
        Toast t = Toast.makeText(this, filepath + " deleted", Toast.LENGTH_LONG);
        t.show();
    }
}
