package life.lookup.audioh.utils;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.RequiresPermission;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;

public class LocationHelper implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener,
        ResultCallback<LocationSettingsResult> {

    /**
     * Constant used in the location settings dialog.
     */
    protected static final int REQUEST_CHECK_SETTINGS = 0x1;
    private static final int REQUEST_RESOLVE_ERROR = 1001; // Request code to use when launching the resolution activity
    private static final int REQUEST_LOCATION_PERMISSION = 12;

    private static final String LOG_TAG = LocationHelper.class.getSimpleName();
    private Activity mContext;
    private LocationResult mCallback;
    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    private boolean mResolvingError, mActivityStarted;
    private View mMain;

    public LocationHelper(Activity context, View mainView) {
        mContext = context;
        mCallback = (LocationResult) context;
        mMain = mainView;

        mLocationRequest = buildLocationRequest();

        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            createGoogleApiClient();
        } else {
            requestLocationPermission();
        }
    }

    private void createGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder(mContext)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();

        if (mActivityStarted) {
            mGoogleApiClient.connect();
        }
    }

    public void onActivityStart() {
        mActivityStarted = true;
        if (mGoogleApiClient != null) {
            mGoogleApiClient.connect();
        }
    }

    public void onActivityStop() {
        mActivityStarted = false;
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            stopLocationUpdates();
            mGoogleApiClient.disconnect();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        Log.v(LOG_TAG, "User agreed to make required location settings changes.");
                        getLocation();
                        break;
                    case Activity.RESULT_CANCELED:
                        Log.v(LOG_TAG, "User chose not to make required location settings changes.");
                        mCallback.onLocationUnavailable();
                        break;
                }
                break;
            case REQUEST_RESOLVE_ERROR:
                mResolvingError = false;
                if (resultCode == Activity.RESULT_OK) {
                    // Make sure the app is not already connected or attempting to connect
                    if (!mGoogleApiClient.isConnecting() && !mGoogleApiClient.isConnected()) {
                        mGoogleApiClient.connect();
                    }
                } else {
                    mCallback.onLocationUnavailable();
                }
                break;
        }
    }

    //
    // GoogleApiClient.ConnectionCallbacks
    //
    @Override
    public void onConnected(Bundle bundle) {
        Log.d(LOG_TAG, "Connected to GoogleApiClient");
        checkLocationSettings();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.d(LOG_TAG, "GoogleApiClient Connection suspended");
        mCallback.onLocationUnavailable();
    }

    //
    // GoogleApiClient.OnConnectionFailedListener
    //
    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.d(LOG_TAG, "Connection failed: ConnectionResult.getErrorCode() = " + result.getErrorCode());

        if (mResolvingError) {
            // Already attempting to resolve an error.
            return;
        }

        if (result.hasResolution()) {
            try {
                mResolvingError = true;
                result.startResolutionForResult(mContext, REQUEST_RESOLVE_ERROR);
            } catch (IntentSender.SendIntentException e) {
                // There was an error with the resolution intent. Try again.
                mGoogleApiClient.connect();
            }
        } else {
            // Show dialog using GoogleApiAvailability.getErrorDialog()
            GoogleApiAvailability.getInstance()
                    .getErrorDialog(mContext, result.getErrorCode(), REQUEST_RESOLVE_ERROR).show();
            mResolvingError = true;
        }
    }

    //
    // ResultCallback<LocationSettingsResult>
    //
    @Override
    public void onResult(LocationSettingsResult locationSettingsResult) {
        final Status status = locationSettingsResult.getStatus();
        switch (status.getStatusCode()) {
            case LocationSettingsStatusCodes.SUCCESS:
                Log.d(LOG_TAG, "All location settings are satisfied.");
                getLocation();
                break;
            case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                Log.d(LOG_TAG, "Location settings are not satisfied. Show the user a dialog to" +
                        "upgrade location settings ");

                try {
                    // Show the dialog by calling startResolutionForResult(), and check the result
                    // in onActivityResult().
                    status.startResolutionForResult(mContext, REQUEST_CHECK_SETTINGS);
                } catch (IntentSender.SendIntentException e) {
                    Log.d(LOG_TAG, "PendingIntent unable to execute request.");
                }
                return;
            case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                Log.d(LOG_TAG, "Location settings are inadequate, and cannot be fixed here. Dialog " +
                        "not created.");
                mCallback.onLocationUnavailable();
                break;
        }
    }

    //
    // LocationListener
    //
    @Override
    public void onLocationChanged(Location location) {
        if (location == null)
            return;

        Log.v(LOG_TAG, "Location available");
        stopLocationUpdates();
        mCallback.onLocationAvailable(location);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_LOCATION_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.v(LOG_TAG, "Location permission granted");
                createGoogleApiClient();
            } else {
                Log.v(LOG_TAG, "Location permission denied");
                mCallback.onLocationUnavailable();
            }
        }
    }

    private void requestLocationPermission() {
        Log.v(LOG_TAG, "Requesting permission");
        if (ActivityCompat.shouldShowRequestPermissionRationale(mContext,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Show dialog explaining why we need location
            Snackbar.make(mMain, "We need location to improve bird recognition",
                    Snackbar.LENGTH_INDEFINITE).setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ActivityCompat.requestPermissions(mContext, new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
                }
            }).show();
        } else {
            ActivityCompat.requestPermissions(mContext, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        }
    }

    @RequiresPermission(anyOf = {
            Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION})
    private void getLocation() {
        Location result = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);
        if (result != null) {
            Log.v(LOG_TAG, "getLastLocation returns valid location");
            mCallback.onLocationAvailable(result);
        } else {
            startLocationUpdates();
        }
    }

    private void startLocationUpdates() {
        Log.v(LOG_TAG, "Starting location updates");
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,
                mLocationRequest, this);
    }

    private void stopLocationUpdates() {
        Log.v(LOG_TAG, "Stopping location updates");
        LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient, this);
    }

    private static LocationRequest buildLocationRequest() {
        LocationRequest request = new LocationRequest();
        request.setInterval(60000);
        request.setFastestInterval(1000);
        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return request;
    }

    protected void checkLocationSettings() {
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(mLocationRequest);
        LocationSettingsRequest settingsRequest = builder.build();

        LocationServices.SettingsApi.checkLocationSettings(mGoogleApiClient, settingsRequest)
                .setResultCallback(this);
    }

    public interface LocationResult {
        void onLocationAvailable(Location location);
        void onLocationUnavailable();
    }
}
