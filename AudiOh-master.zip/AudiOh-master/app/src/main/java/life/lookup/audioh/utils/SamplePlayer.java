package life.lookup.audioh.utils;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.util.Log;

import java.nio.ShortBuffer;

public class SamplePlayer {
    public interface PlaybackListener {
        void onProgress(int progress);
        void onCompletion();
    }

    private static final String LOG_TAG = SamplePlayer.class.getSimpleName();

    private ShortBuffer mSamples;
    private int mSampleRate;
    private int mChannels;
    private int mNumSamples;  // Number of samples per channel.
    private AudioTrack mAudioTrack;
    private int mBufferSize;
    private StreamThread mStreamThread;
    private PlaybackListener mListener;

    public SamplePlayer(ShortBuffer samples, int sampleRate, int audioFormat, int channels, int numSamples) {
        mSamples = samples;
        mSampleRate = sampleRate;
        mChannels = channels;
        mNumSamples = numSamples;
        mBufferSize = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, audioFormat);
        if (mBufferSize == AudioTrack.ERROR || mBufferSize == AudioTrack.ERROR_BAD_VALUE)
        {
            mBufferSize = sampleRate * channels * 2;
        }

        mAudioTrack = new AudioTrack(
                AudioManager.STREAM_MUSIC,
                mSampleRate,
                mChannels == 1 ? AudioFormat.CHANNEL_OUT_MONO : AudioFormat.CHANNEL_OUT_STEREO,
                audioFormat,
                mBufferSize,
                AudioTrack.MODE_STREAM);

        mAudioTrack.setPlaybackPositionUpdateListener(
                new AudioTrack.OnPlaybackPositionUpdateListener() {
                    @Override
                    public void onPeriodicNotification(AudioTrack track) {
                        if (mListener != null && isPlaying()) {
                            mListener.onProgress((track.getPlaybackHeadPosition() * 1000) / mSampleRate);
                        }
                    }

                    @Override
                    public void onMarkerReached(AudioTrack track) {
                        Log.v(LOG_TAG, "Audio file end reached");
                        stop();
                        if (mListener != null) {
                            mListener.onCompletion();
                        }
                    }
                }, new Handler(Looper.getMainLooper()));
        mListener = null;
    }

    public SamplePlayer(@NonNull RawSoundFile sf) {
        this(sf.getSamples(), sf.getSampleRate(), sf.getAudioFormat(), sf.getChannelsCount(), sf.getNumSamples());
    }

    public void setOnCompletionListener(PlaybackListener listener) {
        mListener = listener;
    }

    public boolean isPlaying() {
        return mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PLAYING;
    }

    public boolean isPaused() {
        return mAudioTrack.getPlayState() == AudioTrack.PLAYSTATE_PAUSED;
    }

    public void start() {
        if (isPlaying()) {
            return;
        }

        mAudioTrack.flush();

        mStreamThread = new StreamThread();
        new Thread(mStreamThread).start();
        mAudioTrack.setPositionNotificationPeriod(mSampleRate / 30);
        mAudioTrack.setNotificationMarkerPosition(mNumSamples);
        mAudioTrack.play();

        Log.v(LOG_TAG, "Playback started");
    }

    public void pause() {
        if (isPlaying()) {
            mAudioTrack.pause();
            // mAudioTrack.write() should block if it cannot write.

            Log.v(LOG_TAG, "Audio playback paused");
        }
    }

    public void stop() {
        if (isPlaying() || isPaused()) {
            mStreamThread.stop();
            mAudioTrack.pause();  // pause() stops the playback immediately.
            mAudioTrack.stop();   // Unblock mAudioTrack.write() to avoid deadlocks.
            mAudioTrack.flush();  // just in case...

            Log.v(LOG_TAG, "Audio playback stopped");
        }
    }

    public void release() {
        stop();
        mAudioTrack.release();
    }

    public int getCurrentPosition() {
        return (int) (mAudioTrack.getPlaybackHeadPosition() * (1000.0 / mSampleRate));
    }

    private class StreamThread implements Runnable {
        private boolean mKeepPlaying = true;
        private short[] mBuffer;

        public StreamThread() {
            mBuffer = new short[mBufferSize];
        }

        public void stop() {
            mKeepPlaying = false;
        }

        @Override
        public void run() {
            Log.v(LOG_TAG, "Audio streaming started");

            mSamples.rewind();
            int limit = mNumSamples * mChannels;
            int totalWritten = 0;
            while (mSamples.position() < limit && mKeepPlaying) {
                int numSamplesLeft = limit - mSamples.position();
                int samplesToWrite;
                if (numSamplesLeft >= mBuffer.length) {
                    mSamples.get(mBuffer);
                    samplesToWrite = mBuffer.length;
                } else {
                    for(int i = numSamplesLeft; i < mBuffer.length; i++) {
                        mBuffer[i] = 0;
                    }
                    mSamples.get(mBuffer, 0, numSamplesLeft);
                    samplesToWrite = numSamplesLeft;
                }
                totalWritten += samplesToWrite;
                mAudioTrack.write(mBuffer, 0, samplesToWrite);
            }

            Log.v(LOG_TAG, "Audio streaming finished. Samples written: " + totalWritten);
        }
    }
}
