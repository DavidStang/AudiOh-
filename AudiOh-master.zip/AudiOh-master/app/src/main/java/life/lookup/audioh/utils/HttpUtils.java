package life.lookup.audioh.utils;

import org.apache.http.entity.mime.MultipartEntity;

import java.io.IOError;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpUtils {
    private static final int CONNECTION_TIMEOUT = 10000;
    private static final int READ_TIMEOUT = 15000;

    public static boolean postUpload(String address, InputStream stream) throws IOError, IOException {
        URL url = new URL(address);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(CONNECTION_TIMEOUT);
        conn.setReadTimeout(READ_TIMEOUT);
        conn.setRequestMethod("POST");
        conn.setDoInput(true);
        conn.setDoOutput(true);

        OutputStream os;
        try {
            os = conn.getOutputStream();
        } catch (IOException e) {
            return false;
        }
        try {
            IOUtils.copy(stream, os);
        } finally {
            os.flush();
            os.close();
        }

        int responseCode = conn.getResponseCode();
        return responseCode == HttpURLConnection.HTTP_OK;
    }

    public static HttpResponse postUpload(String address, MultipartEntity data) throws IOError, IOException {
        URL url = new URL(address);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setConnectTimeout(CONNECTION_TIMEOUT);
        conn.setReadTimeout(READ_TIMEOUT);
        conn.setRequestMethod("POST");
        conn.setRequestProperty(data.getContentType().getName(), data.getContentType().getValue());
        conn.setRequestProperty("Content-Length", String.valueOf(data.getContentLength()));
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);

        OutputStream request = conn.getOutputStream();
        try {
            data.writeTo(request);
        } finally {
            request.flush();
            request.close();
        }

        HttpUtils.HttpResponse response = new HttpUtils.HttpResponse();
        response.ResponseCode = conn.getResponseCode();
        response.ContentType = conn.getContentType();
        response.ContentEncoding = conn.getContentEncoding();
        InputStream res = conn.getInputStream();
        try {
            response.Content = IOUtils.toString(res);
        } finally {
            res.close();
        }

        conn.disconnect();

        return response;
    }

    public static class HttpResponse {
        public static HttpResponse ErrorResponse(Exception error) {
            HttpResponse response = new HttpResponse();
            response.Error = error;
            return response;
        }

        public String Content, ContentType, ContentEncoding;
        public int ResponseCode;
        public Exception Error;
    }
}
