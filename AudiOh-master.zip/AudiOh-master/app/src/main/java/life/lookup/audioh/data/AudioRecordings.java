package life.lookup.audioh.data;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Contract class for AudioRecordings
 */
public class AudioRecordings {
    public static final String AUTHORITY = "life.lookup.audioh";
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY);

    static final String PATH_AUDIO_RECORDINGS = "recordings";

    private AudioRecordings() {}

    public static final class Recording implements BaseColumns {

        public static final Uri CONTENT_URI =
                AudioRecordings.BASE_CONTENT_URI.buildUpon().appendPath(PATH_AUDIO_RECORDINGS).build();
        public static final String CONTENT_TYPE =
                ContentResolver.CURSOR_DIR_BASE_TYPE + "/" + AUTHORITY + "/" + PATH_AUDIO_RECORDINGS;
        public static final String CONTENT_ITEM_TYPE =
                ContentResolver.CURSOR_ITEM_BASE_TYPE + "/" + AUTHORITY + "/" + PATH_AUDIO_RECORDINGS;

        static final String TABLE_NAME = "recordings";

        public static final String FILE_PATH = "_data";
        public static final String DATE = "date";
        public static final String COORD_LAT = "coord_lat";
        public static final String COORD_LONG = "coord_long";
        public static final String DURATION = "duration";
        public static final String UPLOADED = "uploaded";
    }
}
