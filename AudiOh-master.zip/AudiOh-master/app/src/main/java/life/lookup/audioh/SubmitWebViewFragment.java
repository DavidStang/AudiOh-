package life.lookup.audioh;

import android.annotation.TargetApi;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

import life.lookup.audioh.loaders.WebpageLoader;
import life.lookup.audioh.utils.HttpUtils;

public class SubmitWebViewFragment extends Fragment
        implements LoaderManager.LoaderCallbacks<HttpUtils.HttpResponse> {
    public SubmitWebViewFragment() {
        setHasOptionsMenu(true);
    }

    private Uri mRecordingUri;
    private static final int UPLOAD_LOADER = 3;
    private WebView mWebView;
    private ProgressBar mProgress;

    public static SubmitWebViewFragment createInstance(Uri recordingUri) {
        SubmitWebViewFragment fragment = new SubmitWebViewFragment();
        Bundle args = new Bundle();
        args.putParcelable(PlaybackFragment.ARG_RECORDING_URI, recordingUri);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_submitwebview, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_upload) {
            mProgress.setVisibility(View.VISIBLE);
            mWebView.setVisibility(View.GONE);
            getLoaderManager().restartLoader(UPLOAD_LOADER, null, this);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getLoaderManager().initLoader(UPLOAD_LOADER, null, this);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null) {
            mRecordingUri = args.getParcelable(PlaybackFragment.ARG_RECORDING_URI);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_submit, container, false);
        mWebView = (WebView) view.findViewById(R.id.webPage);
        mProgress = (ProgressBar) view.findViewById(R.id.webPage_progress);

        mProgress.setVisibility(View.VISIBLE);
        mWebView.setVisibility(View.GONE);

        mWebView.setWebViewClient(new WebViewClient());

        return view;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onPause() {
        super.onPause();
        mWebView.onPause();
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onResume() {
        mWebView.onResume();
        super.onResume();
    }

    @Override
    public Loader<HttpUtils.HttpResponse> onCreateLoader(int id, Bundle args) {
        return new WebpageLoader(getActivity(), mRecordingUri);
    }

    @Override
    public void onLoadFinished(Loader<HttpUtils.HttpResponse> loader, HttpUtils.HttpResponse data) {
        mProgress.setVisibility(View.GONE);
        mWebView.setVisibility(View.VISIBLE);

        if (data.Error != null) {
            String errorReport = "<h3>%s</h3>" +
                    "<section>" +
                    "<title>Debug info</title>" +
                    "<p>An exception of type <strong>%s</strong> occurred.</p>" +
                    "<p>%s</p>" +
                    "</section>";
            Writer stacktraceWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stacktraceWriter);
            data.Error.printStackTrace(printWriter);
            String message = String.format(errorReport,
                    getString(R.string.upload_issue),
                    data.Error.getClass().getName(),
                    stacktraceWriter.toString());
            mWebView.loadData(message, "text/html", "UTF8");
        } else {
            mWebView.loadDataWithBaseURL(getString(R.string.server_audioUpload),
                    data.Content, data.ContentType, data.ContentEncoding, null);
        }
    }

    @Override
    public void onLoaderReset(Loader<HttpUtils.HttpResponse> loader) {

    }

    @Override
    public void onDestroy() {
        if (mWebView != null) {
            mWebView.destroy();
            mWebView = null;
        }
        super.onDestroy();
    }
}
