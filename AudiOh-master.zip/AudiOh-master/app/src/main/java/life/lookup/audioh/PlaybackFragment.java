package life.lookup.audioh;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.nio.ShortBuffer;

import life.lookup.audioh.loaders.SoundFileLoader;
import life.lookup.audioh.utils.RawSoundFile;
import life.lookup.audioh.utils.SamplePlayer;
import life.lookup.audioh.views.StaticWaveformView;

public class PlaybackFragment extends Fragment implements LoaderManager.LoaderCallbacks<RawSoundFile> {

    public static final String ARG_RECORDING_URI = "recording_uri";
    private static final int PLAYBACK_LOADER = 2;

    public PlaybackFragment() {
        setHasOptionsMenu(true);
    }

    private RawSoundFile mSoundFile;
    private Uri mRecordingUri;
    private StaticWaveformView mWaveformView;
    private TextView mInfo;
    private ImageButton mPlayButton;
    private String mCaption = "";
    private boolean mIsPlaying;
    private SamplePlayer mPlayer;

    public static PlaybackFragment createInstance(Uri recordingUri) {
        PlaybackFragment fragment = new PlaybackFragment();
        Bundle args = new Bundle();
        args.putParcelable(ARG_RECORDING_URI, recordingUri);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_playback, menu);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getLoaderManager().initLoader(PLAYBACK_LOADER, null, this);
    }

    @Override
    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);

        mSoundFile = null;
        mPlayer = null;
        mIsPlaying = false;

        Bundle args = getArguments();
        if (args != null) {
            mRecordingUri = args.getParcelable(ARG_RECORDING_URI);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_playback, container, false);

        loadGui(view);

        return view;
    }

    @Override
    public void onPause() {
        super.onPause();

        handlePause();
    }

    @Override
    public void onStop() {
        if (mPlayer != null) {
            mPlayer.release();
            mPlayer = null;
        }

        super.onStop();
    }

    @Override
    public void onStart() {
        super.onStart();

        if (mPlayer == null && mSoundFile != null) {
            mPlayer = new SamplePlayer(mSoundFile);
        }
    }

    private void loadGui(View view) {

        mPlayButton = (ImageButton) view.findViewById(R.id.play);
        mPlayButton.setOnClickListener(mPlayListener);

        Button nextButton = (Button) view.findViewById(R.id.next);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startEdit = new Intent(getActivity(), WebViewActivity.class);
                startEdit.putExtra(PlaybackFragment.ARG_RECORDING_URI, mRecordingUri);
                startActivity(startEdit);
            }
        });

        enableDisableButtons();

        mWaveformView = (StaticWaveformView) view.findViewById(R.id.waveform);

        mInfo = (TextView) view.findViewById(R.id.info);
        mInfo.setText(mCaption);
    }

    private void finishOpeningSoundFile() {
        mWaveformView.setAudioLength(mSoundFile.getLength());
        mWaveformView.updateAudioData(copyBuffer(mSoundFile.getSamples()));

        mCaption = "raw, " +
                mSoundFile.getSampleRate() + " Hz, " +
                String.format("%.2f ", mSoundFile.getLength() / 1000f) +
                getResources().getString(R.string.time_seconds);
        mInfo.setText(mCaption);
    }

    private static short[] copyBuffer(ShortBuffer buffer) {
        short[] data = new short[buffer.limit()];
        buffer.rewind();
        buffer.get(data);
        return data;
    }

    private void enableDisableButtons() {
        if (mIsPlaying) {
            mPlayButton.setImageResource(android.R.drawable.ic_media_pause);
            mPlayButton.setContentDescription(getResources().getText(R.string.stop));
        } else {
            mPlayButton.setImageResource(android.R.drawable.ic_media_play);
            mPlayButton.setContentDescription(getResources().getText(R.string.play));
        }
    }

    private synchronized void handlePause() {
        if (mPlayer != null && mPlayer.isPlaying()) {
            mPlayer.pause();
        }
        mIsPlaying = false;
        enableDisableButtons();
    }

    private synchronized void onPlay() {
        if (mIsPlaying) {
            handlePause();
            return;
        }

        if (mPlayer == null) {
            // Not initialized yet
            return;
        }

        try {
            mPlayer.setOnCompletionListener(new SamplePlayer.PlaybackListener() {
                @Override
                public void onProgress(int progress) {
                    mWaveformView.updateAudioProgress(progress);
                }

                @Override
                public void onCompletion() {
                    mWaveformView.updateAudioProgress(mSoundFile.getLength());
                    handlePause();
                }
            });
            mIsPlaying = true;

            mPlayer.start();
            enableDisableButtons();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private View.OnClickListener mPlayListener = new View.OnClickListener() {
        public void onClick(View sender) {
            onPlay();
        }
    };

    @Override
    public Loader<RawSoundFile> onCreateLoader(int id, Bundle args) {
        return new SoundFileLoader(getActivity(), mRecordingUri);
    }

    @Override
    public void onLoadFinished(Loader<RawSoundFile> loader, RawSoundFile soundFile) {
        mSoundFile = soundFile;
        if (soundFile != null) {
            mPlayer = new SamplePlayer(mSoundFile);
            finishOpeningSoundFile();
        }
    }

    @Override
    public void onLoaderReset(Loader<RawSoundFile> loader) {
    }

}