package life.lookup.audioh.recording;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.location.Location;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.concurrent.BlockingQueue;

import life.lookup.audioh.data.AudioRecordings;
import life.lookup.audioh.utils.AudioUtils;
import life.lookup.audioh.utils.ContentProviderUtils;
import life.lookup.audioh.utils.RawSoundFile;

public class EncodingThread extends AudioThreadBase {
    private final String LOG_TAG = EncodingThread.class.getSimpleName();

    private File mFile;
    private Location mLocation;
    private AudioDataReceivedListener mAudioDataReceivedListener;
    private Uri mRecordingUri;

    public EncodingThread(Context context, BlockingQueue<short[]> data, Location location,
                          AudioThreadStatusListener listener, AudioDataReceivedListener audioDataReceivedListener) {
        super(context, data, listener);
        mLocation = location;
        mAudioDataReceivedListener = audioDataReceivedListener;
    }

    public Uri getRecordingUri() {
        return mRecordingUri;
    }

    @Override
    public void run() {
        Log.v(LOG_TAG, "Start");

        mFile = createAudioFile();
        if (mFile == null) {
            Log.e(LOG_TAG, "Could not create file!");
            onFailure("Could not create file!");
            return;
        }

        DataOutputStream dataStream;
        try {
            dataStream = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(mFile)));
        } catch (IOException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
            onFailure("Could not create file!", e);
            return;
        }

        onStarted();

        Log.v(LOG_TAG, "Start receiving audio data from RecordingThread");

        // Pull data from audio thread
        try {
            short[] item;
            while (!Arrays.equals((item = mQueue.take()), MARKER_BIT)) {
                for (short s : item) {
                    dataStream.writeShort(s);
                }

                if (mAudioDataReceivedListener != null)
                    mAudioDataReceivedListener.onAudioDataReceived(item);
            }
        } catch (InterruptedException | IOException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
        }

        Log.v(LOG_TAG, "All audio data from RecordingThread received");

        try {
            dataStream.flush();
            dataStream.close();
            Log.v(LOG_TAG, "Audio file saved to disk");
        } catch (IOException e) {
            Log.e(LOG_TAG, e.getMessage(), e);
            onFailure("Could not save file", e);
        }

        // Write record to db
        addDbRecord();

        onCompleted();
    }

    private File createAudioFile() {
        final String fileName = String.format("audioRecord%d.pcm", getNextRecordingId());
        final String folderName = "recordings";

        // Get directory
        File recordingsDir = null;
        if (isExternalStorageWritable()) {
            recordingsDir = getContext().getExternalFilesDir(folderName);
        }
        if (recordingsDir == null) {
            recordingsDir = new File(getContext().getFilesDir(), folderName);
        }
        if (!recordingsDir.exists()) {
            if (!recordingsDir.mkdirs()) {
                return null;
            }
            if (recordingsDir.getUsableSpace() < (RawSoundFile.SAMPLING_RATE * 2 * 30)) {
                // Recordings dir doesn't have enough space to store 30 seconds of audio
                return null;
            }
        }

        // Get file
        File recordingFile = new File(recordingsDir, fileName);
        try {
            if (recordingFile.createNewFile()) {
                Log.v(LOG_TAG, "File " + recordingFile + " created");
            } else {
                Log.v(LOG_TAG, "File " + recordingFile + " already created. Will overwrite");
            }
        } catch (IOException e) {
            return null;
        }
        return recordingFile;
    }

    private void addDbRecord() {
        int audioFileDuration = AudioUtils.getAudioLength((mFile.length() / 2), RawSoundFile.SAMPLING_RATE);
        ContentValues values = new ContentValues();
        values.put(AudioRecordings.Recording.FILE_PATH, mFile.getAbsolutePath());
        values.put(AudioRecordings.Recording.DATE, System.currentTimeMillis());
        values.put(AudioRecordings.Recording.DURATION, audioFileDuration);
        if (mLocation != null) {
            values.put(AudioRecordings.Recording.COORD_LAT, mLocation.getLatitude());
            values.put(AudioRecordings.Recording.COORD_LONG, mLocation.getLongitude());
        }

        ContentResolver resolver = getContext().getContentResolver();
        try {
            mRecordingUri = resolver.insert(AudioRecordings.Recording.CONTENT_URI, values);
            Log.v(LOG_TAG, "Data inserted. Uri: " + mRecordingUri);
        } catch (Exception e) {
            Log.e(LOG_TAG, "DB insert error", e);
        }
    }

    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private int getNextRecordingId() {
        ContentResolver resolver = getContext().getContentResolver();
        long numRecords = ContentProviderUtils.queryNumEntries(resolver, AudioRecordings.Recording.CONTENT_URI);
        return (int)numRecords + 1;
    }
}
