package life.lookup.audioh.loaders;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.Settings;
import android.support.v4.content.AsyncTaskLoader;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;

import java.io.IOException;
import java.io.InputStream;

import life.lookup.audioh.R;
import life.lookup.audioh.data.AudioRecordings;
import life.lookup.audioh.utils.AudioUtils;
import life.lookup.audioh.utils.HttpUtils;
import life.lookup.audioh.utils.RawSoundFile;
import life.lookup.audioh.utils.Utils;

public class WebpageLoader extends AsyncTaskLoader<HttpUtils.HttpResponse> {
    public WebpageLoader(Context context, Uri uri) {
        super(context);
        mRecordingUri = uri;
    }

    private HttpUtils.HttpResponse mData;
    private Uri mRecordingUri;

    @Override
    public HttpUtils.HttpResponse loadInBackground() {
        if (mRecordingUri == null)
            return HttpUtils.HttpResponse.ErrorResponse(new IllegalArgumentException("uri"));

        WebpageData data = new WebpageData();
        ContentResolver resolver = getContext().getContentResolver();
        String uid = Settings.Secure.getString(resolver, Settings.Secure.ANDROID_ID);
        String email = Utils.getUserEmail(getContext());
        try {
            InputStream stream = resolver.openInputStream(mRecordingUri);
            data.soundFile = RawSoundFile.openStream(stream);
        } catch (IOException e) {
            return HttpUtils.HttpResponse.ErrorResponse(e);
        }

        Cursor c = resolver.query(mRecordingUri, new String[]{
                AudioRecordings.Recording.COORD_LAT,
                AudioRecordings.Recording.COORD_LONG,
                AudioRecordings.Recording.FILE_PATH
        }, null, null, null);
        c.moveToFirst();
        double latitude = c.getDouble(0);
        double longitude = c.getDouble(1);
        String filepath = c.getString(2);
        data.filename = Uri.parse(filepath).getLastPathSegment();
        c.close();

        MultipartEntity multipartEntity = getPostData(data);
        Uri uri = Uri.parse(getContext().getString(R.string.server_audioUpload)).buildUpon()
                .appendQueryParameter("did", uid)
                .appendQueryParameter("lat", String.valueOf(latitude))
                .appendQueryParameter("lng", String.valueOf(longitude))
                .appendQueryParameter("em", email)
                .build();
        try {
            return HttpUtils.postUpload(uri.toString(), multipartEntity);
        } catch (IOException e) {
            return HttpUtils.HttpResponse.ErrorResponse(e);
        }
    }

    @Override
    public void deliverResult(HttpUtils.HttpResponse data) {
        if (isReset()) {
            // The Loader has been reset; ignore the result and invalidate the data.
            releaseResources(data);
            return;
        }

        // Hold a reference to the old data so it doesn't get garbage collected.
        // We must protect it until the new data has been delivered.
        HttpUtils.HttpResponse oldData = mData;
        mData = data;

        if (isStarted()) {
            // If the Loader is in a started state, deliver the results to the
            // client. The superclass method does this for us.
            super.deliverResult(data);
        }

        // Invalidate the old data as we don't need it any more.
        if (oldData != null && oldData != data) {
            releaseResources(oldData);
        }
    }

    @Override
    protected void onStartLoading() {
        if (mData != null) {
            // Deliver any previously loaded data immediately.
            deliverResult(mData);
        }

        if (takeContentChanged() || mData == null) {
            // When the observer detects a change, it should call onContentChanged()
            // on the Loader, which will cause the next call to takeContentChanged()
            // to return true. If this is ever the case (or if the current data is
            // null), we force a new load.
            forceLoad();
        }
    }

    @Override
    protected void onStopLoading() {
        // The Loader is in a stopped state, so we should attempt to cancel the
        // current load (if there is one).
        cancelLoad();
    }

    @Override
    protected void onReset() {
        // Ensure the loader has been stopped.
        onStopLoading();

        if (mData != null) {
            releaseResources(mData);
            mData = null;
        }
    }

    @Override
    public void onCanceled(HttpUtils.HttpResponse data) {
        // Attempt to cancel the current asynchronous load.
        super.onCanceled(data);

        releaseResources(data);
    }

    private void releaseResources(HttpUtils.HttpResponse data) {
    }

    private MultipartEntity getPostData(WebpageData recordingsData) {
        byte[] encodedAudio = AudioUtils.encodeAudioFileToWave(recordingsData.soundFile);
        String filename = recordingsData.filename.replace(".pcm", ".wav");

        MultipartEntity data = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
        data.addPart("finame", new ByteArrayBody(encodedAudio, filename)); // File

        return data;
    }

    private class WebpageData {
        String filename;
        RawSoundFile soundFile;
    }
}
