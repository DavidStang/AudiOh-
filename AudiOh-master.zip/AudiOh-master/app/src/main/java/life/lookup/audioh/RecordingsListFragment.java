package life.lookup.audioh;

import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v4.widget.CursorAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DateFormat;

import life.lookup.audioh.data.AudioRecordings;

public class RecordingsListFragment extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor> {

    public RecordingsListFragment() {
    }

    private static final int LIST_LOADER = 1;
    private RecordingsAdapter mAdapter;

    private static String[] RECORDING_PROJECTION = new String[] {
            AudioRecordings.Recording._ID,
            AudioRecordings.Recording.DATE,
            AudioRecordings.Recording.FILE_PATH,
            AudioRecordings.Recording.DURATION
    };

    private static final int RECORDING_ID = 0;
    private static final int RECORDING_DATE = 1;
    private static final int RECORDING_FILE_PATH = 2;
    private static final int RECORDING_DURATION = 3;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = super.onCreateView(inflater, container, savedInstanceState);

        mAdapter = new RecordingsAdapter(getActivity(), null);
        setListAdapter(mAdapter);

        return rootView;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        setEmptyText(getString(R.string.recordings_list_empty));
        this.getLoaderManager().initLoader(LIST_LOADER, null, this);
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        Uri itemUri = ContentUris.withAppendedId(AudioRecordings.Recording.CONTENT_URI, id);
        Intent startEdit = new Intent(getActivity(), EditActivity.class);
        startEdit.putExtra(PlaybackFragment.ARG_RECORDING_URI, itemUri);
        startActivity(startEdit);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new CursorLoader(getActivity(), AudioRecordings.Recording.CONTENT_URI,
                RECORDING_PROJECTION , null, null, null);
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        mAdapter.swapCursor(data);
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        mAdapter.swapCursor(null);
    }

    class RecordingsAdapter extends CursorAdapter {
        public RecordingsAdapter(Context context, Cursor cursor) {
            super(context, cursor, 0);
        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup parent) {
            return LayoutInflater.from(context).inflate(R.layout.item_recording, parent, false);
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            // Date
            long dateMills = cursor.getLong(RECORDING_DATE);
            String date = DateFormat.getInstance().format(dateMills);
            TextView dateView = (TextView) view.findViewById(R.id.item_recording_date);
            dateView.setText(date);

            // Filename
            String filepath = cursor.getString(RECORDING_FILE_PATH);
            String filename = Uri.parse(filepath).getLastPathSegment();
            TextView fileNameView = (TextView) view.findViewById(R.id.item_recording_filename);
            fileNameView.setText(filename);

            // Duration
            int duration = cursor.getInt(RECORDING_DURATION);
            TextView durationView = (TextView) view.findViewById(R.id.item_recording_duration);
            durationView.setText(String.format("%.2f ", duration / 1000f) +
                    getResources().getString(R.string.time_seconds));
        }
    }
}
