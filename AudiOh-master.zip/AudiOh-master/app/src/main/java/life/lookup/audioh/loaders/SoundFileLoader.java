package life.lookup.audioh.loaders;

import android.content.Context;
import android.net.Uri;
import android.support.v4.content.AsyncTaskLoader;

import java.io.IOException;
import java.io.InputStream;

import life.lookup.audioh.utils.RawSoundFile;

public class SoundFileLoader extends AsyncTaskLoader<RawSoundFile> {

    public SoundFileLoader(Context context, Uri uri) {
        super(context);
        mRecordingUri = uri;
    }

    private RawSoundFile mSoundFile;
    private Uri mRecordingUri;

    @Override
    public RawSoundFile loadInBackground() {
        if (mRecordingUri == null)
            return null;
        try {
            InputStream stream = getContext().getContentResolver().openInputStream(mRecordingUri);
            return RawSoundFile.openStream(stream);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void deliverResult(RawSoundFile data) {
        if (isReset()) {
            // The Loader has been reset; ignore the result and invalidate the data.
            releaseResources(data);
            return;
        }

        // Hold a reference to the old data so it doesn't get garbage collected.
        // We must protect it until the new data has been delivered.
        RawSoundFile oldData = mSoundFile;
        mSoundFile = data;

        if (isStarted()) {
            // If the Loader is in a started state, deliver the results to the
            // client. The superclass method does this for us.
            super.deliverResult(data);
        }

        // Invalidate the old data as we don't need it any more.
        if (oldData != null && oldData != data) {
            releaseResources(oldData);
        }
    }

    @Override
    protected void onStartLoading() {
        if (mSoundFile != null) {
            // Deliver any previously loaded data immediately.
            deliverResult(mSoundFile);
        }

        if (takeContentChanged() || mSoundFile == null) {
            // When the observer detects a change, it should call onContentChanged()
            // on the Loader, which will cause the next call to takeContentChanged()
            // to return true. If this is ever the case (or if the current data is
            // null), we force a new load.
            forceLoad();
        }
    }

    @Override
    protected void onStopLoading() {
        // The Loader is in a stopped state, so we should attempt to cancel the
        // current load (if there is one).
        cancelLoad();
    }

    @Override
    protected void onReset() {
        // Ensure the loader has been stopped.
        onStopLoading();

        if (mSoundFile != null) {
            releaseResources(mSoundFile);
            mSoundFile = null;
        }
    }

    @Override
    public void onCanceled(RawSoundFile data) {
        // Attempt to cancel the current asynchronous load.
        super.onCanceled(data);

        releaseResources(data);
    }

    private void releaseResources(RawSoundFile data) {
    }
}
