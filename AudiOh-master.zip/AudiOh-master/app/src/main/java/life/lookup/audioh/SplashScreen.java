package life.lookup.audioh;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;

import java.io.IOException;

import life.lookup.audioh.utils.HttpUtils;
import life.lookup.audioh.utils.LocationHelper;
import life.lookup.audioh.utils.SubscriptionHelper;
import life.lookup.audioh.utils.Utils;

public class SplashScreen extends AppCompatActivity implements
        SubscriptionHelper.SubscriptionResult,
        LocationHelper.LocationResult {

    private static final String LOG_TAG = SplashScreen.class.getSimpleName();

    private static final String STATE_VCARD_UPLOAD_TASK_FINISHED = "vcard_upload_task_finished";
    private static final String STATE_LOCATION = "location";
    private static final String STATE_WAITING_FOR_LOCATION = "waiting_for_location";
    private static final String STATE_WAITING_FOR_SUBSCRIPTION = "waiting_for_subscription";

    private boolean mVcardUploadTaskFinished, mSubscriptionInfoObtained, mLocationInfoObtained;
    private Location mLocation;
    private View mSplashScreen, mEmailScreen;
    private TextView mStatusText;
    private EditText mEmailText;
    Button mOkButton;
    private SubscriptionHelper mSubscriptionHelper;
    private LocationHelper mLocationHelper;

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        if (!Utils.isWelcomeScreenShown(this)) {
            startActivity(new Intent(this, WelcomeActivity.class));
            finish();
        }

        View main = findViewById(R.id.splash_main);
        mSplashScreen = findViewById(R.id.splash_imageScreen);
        mEmailScreen = findViewById(R.id.splash_emailScreen);
        mStatusText = (TextView) findViewById(R.id.splashStatus);

        // Email upload
        if (!Utils.isUserVcardUploaded(this)) {
            crossfade();

            mEmailText = (EditText) findViewById(R.id.splash_emailText);
            String userEmail = Utils.getUserEmail(this);
            if (userEmail != null) {
                mEmailText.setText(userEmail);
            }
            mEmailText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        handleUserEmailEnter();
                        return true;
                    }
                    return false;
                }
            });

            mOkButton = (Button) mEmailScreen.findViewById(R.id.splash_okButton);
            mOkButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handleUserEmailEnter();
                }
            });
        } else {
            mVcardUploadTaskFinished = true;
        }

        // Location
        mLocationHelper = new LocationHelper(this, main);
        mStatusText.setText(R.string.getting_location);
    }

    @Override
    public void onSubscribeResult(boolean isSubscribed) {
        mSubscriptionInfoObtained = true;
        if (!isSubscribed) {
            new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage("AudiOh can't operate without subscription!")
                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })
                .show();
        } else {
            tryCompleteSetup();
        }
    }

    @Override
    public void onLocationAvailable(Location location) {
        mLocationInfoObtained = true;
        mLocation = location;

        // Subscription
        mStatusText.setText(R.string.getting_subscription);
        mSubscriptionHelper = new SubscriptionHelper(this);

        tryCompleteSetup();
    }

    @Override
    public void onLocationUnavailable() {
        mLocationInfoObtained = true;
        new AlertDialog.Builder(this)
            .setTitle("Error")
            .setMessage("AudiOh can't operate without location information!")
            .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            })
            .show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(STATE_VCARD_UPLOAD_TASK_FINISHED, mVcardUploadTaskFinished);
        outState.putBoolean(STATE_WAITING_FOR_LOCATION, mLocationInfoObtained);
        outState.putParcelable(STATE_LOCATION, mLocation);
        outState.putBoolean(STATE_WAITING_FOR_SUBSCRIPTION, mSubscriptionInfoObtained);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        mVcardUploadTaskFinished = savedInstanceState.getBoolean(STATE_VCARD_UPLOAD_TASK_FINISHED, false);
        mSubscriptionInfoObtained = savedInstanceState.getBoolean(STATE_WAITING_FOR_SUBSCRIPTION, false);
        mLocationInfoObtained = savedInstanceState.getBoolean(STATE_WAITING_FOR_LOCATION, false);
        mLocation = savedInstanceState.getParcelable(STATE_LOCATION);
    }

    @Override
    protected void onStart() {
        super.onStart();
        mLocationHelper.onActivityStart();
    }

    @Override
    protected void onStop() {
        mLocationHelper.onActivityStop();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mSubscriptionHelper != null) {
            mSubscriptionHelper.destroy();
            mSubscriptionHelper = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mLocationHelper.onActivityResult(requestCode, resultCode, data);
        if (mSubscriptionHelper != null) {
            mSubscriptionHelper.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mLocationHelper.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void handleUserEmailEnter() {
        mOkButton.setEnabled(false);
        mEmailText.setEnabled(false);
        String userEmail = mEmailText.getText().toString();
        Utils.saveUserEmail(SplashScreen.this, userEmail);
        new UploadVcardTask().execute(userEmail);
    }

    private void tryCompleteSetup() {
        if (!mLocationInfoObtained || !mSubscriptionInfoObtained || !mVcardUploadTaskFinished)
            return;

        Log.v(LOG_TAG, "Setup complete");
        Intent mainIntent = new Intent(SplashScreen.this, MainActivity.class);
        mainIntent.putExtra(MainActivity.ARG_LOCATION, mLocation);
        startActivity(mainIntent);
        finish();
    }

    private void crossfade() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1)
            crossfadeHoneycomb(mSplashScreen, mEmailScreen);
        else
            crossFadeGingerbread(mSplashScreen, mEmailScreen);
    }

    private void crossfade_back() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR1)
            crossfadeHoneycomb(mEmailScreen, mSplashScreen);
        else
            crossFadeGingerbread(mEmailScreen, mSplashScreen);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR1)
    private static void crossfadeHoneycomb(final View from, final View to) {
        int shortAnimationDuration = to.getResources().getInteger(
                android.R.integer.config_longAnimTime);

        // Set the content view to 0% opacity but visible, so that it is visible
        // (but fully transparent) during the animation.
        to.setAlpha(0f);
        to.setVisibility(View.VISIBLE);

        // Animate the content view to 100% opacity, and clear any animation
        // listener set on the view.
        to.animate()
                .alpha(1f)
                .setDuration(shortAnimationDuration)
                .setListener(null);

        // Animate the loading view to 0% opacity. After the animation ends,
        // set its visibility to GONE as an optimization step (it won't
        // participate in layout passes, etc.)
        from.animate()
                .alpha(0f)
                .setDuration(shortAnimationDuration)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        from.setVisibility(View.GONE);
                    }
                });
    }

    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    private static void crossFadeGingerbread(final View from, final View to) {
        to.setVisibility(View.VISIBLE);
        from.setVisibility(View.GONE);
    }

    private class UploadVcardTask extends AsyncTask<String, Void, Boolean> {

        @Override
        protected void onPreExecute() {
            mVcardUploadTaskFinished = false;
        }

        @Override
        protected Boolean doInBackground(String[] params) {
            byte[] vcardData = createVcard(params[0]);

            boolean result = false;
            String uid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            MultipartEntity data = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
            data.addPart("finame", new ByteArrayBody(vcardData, uid + ".vcf"));
            try {
                HttpUtils.HttpResponse response = HttpUtils.postUpload(getString(R.string.server_vcardUpload), data);
                if (response != null) {
                    result = response.ResponseCode == 200;
                }
            } catch (IOException e) {
                Log.e(LOG_TAG, "Error trying to upload vcard to server", e);
            }

            if (!result)
                Log.v(LOG_TAG, "Could not upload vcard to server");
            else
                Log.v(LOG_TAG, "Vcard uploaded to server");
            Utils.saveUserVcardUploaded(SplashScreen.this, result);
            return result;
        }

        @Override
        protected void onPostExecute(Boolean vcardUploaded) {
            if (!vcardUploaded) {
                Toast t = Toast.makeText(SplashScreen.this, R.string.splash_toast_no_connection,
                        Toast.LENGTH_LONG);
                t.show();
            }

            mVcardUploadTaskFinished = true;
            crossfade_back();
            tryCompleteSetup();
        }

        private byte[] createVcard(String email) {
            return ("BEGIN:VCARD\n" +
                    "VERSION:2.1\n" +
                    "EMAIL;INTERNET:" + email + "\n" +
                    "END:VCARD\n").getBytes();
        }
    }
}
