package life.lookup.audioh.utils;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import com.android.vending.billing.IInAppBillingService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import life.lookup.audioh.R;

public class SubscriptionHelper {
    private static final String[] SUBSCRIPTIONS;
    private static final Set<String> SUBSCRIPTIONS_SET;
    private static final String LOG_TAG = SubscriptionHelper.class.getSimpleName();
    private IInAppBillingService mService;
    private ServiceConnection mServiceConn;
    private Activity mContext;
    private boolean mIsSubscribed;
    protected static final int REQUEST_PURCHASE = 0x2;
    private SubscriptionResult mCallback;
    private String mDialogTitle;

    static {
        SUBSCRIPTIONS = new String[] {
            "99",   // Monthly subscription
            "9.99"  // Yearly subscription
        };
        SUBSCRIPTIONS_SET = new HashSet<>(Arrays.asList(SUBSCRIPTIONS));
    }

    public SubscriptionHelper(Activity context) {
        this(context, context.getString(R.string.dialog_subscribe_title));
    }

    public SubscriptionHelper(Activity context, String dialogTitle) {
        mContext = context;
        mDialogTitle = dialogTitle;

        if (context instanceof SubscriptionResult) {
            mCallback = (SubscriptionResult) context;
        }
        mServiceConn = new ServiceConnection() {
            @Override
            public void onServiceDisconnected(ComponentName name) {
                mService = null;
            }

            @Override
            public void onServiceConnected(ComponentName name,
                                           IBinder service) {
                mService = IInAppBillingService.Stub.asInterface(service);

                mIsSubscribed = checkSubscription();
                if (mIsSubscribed) {
                    if (mCallback != null) {
                        mCallback.onSubscribeResult(true);
                    }
                } else {
                    showSubscribeDialog();
                }
            }
        };

        Intent serviceIntent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        serviceIntent.setPackage("com.android.vending");
        mContext.bindService(serviceIntent, mServiceConn, Context.BIND_AUTO_CREATE);
    }

    public void destroy() {
        if (mServiceConn != null) {
            mContext.unbindService(mServiceConn);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_PURCHASE) {
                int responseCode = data.getIntExtra("RESPONSE_CODE", 0);
                String purchaseData = data.getStringExtra("INAPP_PURCHASE_DATA");
                String dataSignature = data.getStringExtra("INAPP_DATA_SIGNATURE");

                if (resultCode == Activity.RESULT_OK) {
                    try {
                        // TODO: Add security checks
                        JSONObject jo = new JSONObject(purchaseData);
                        String sku = jo.getString("productId");
                        mIsSubscribed = SUBSCRIPTIONS_SET.contains(sku);
                    }
                    catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                if (mCallback != null) {
                    mCallback.onSubscribeResult(mIsSubscribed);
                }
        }
    }

    private boolean checkSubscription() {
        Bundle ownedItems = null;
        try {
            ownedItems = mService.getPurchases(3, mContext.getPackageName(), "subs", null);
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        if (ownedItems != null && ownedItems.getInt("RESPONSE_CODE") == 0) {
            ArrayList<String> ownedSkus = ownedItems.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
            if (ownedSkus != null && ownedSkus.size() > 0) {
                for (String sku : ownedSkus) {
                    if (SUBSCRIPTIONS_SET.contains(sku))
                        return true;
                }
                return false;
            }
        }

        return false;
    }

    private void subscribe(String sku) {
        String devPayload = ""; // TODO: Add proper dev payload and check it
        try {
            Bundle subscribeBundle = mService.getBuyIntent(3, mContext.getPackageName(), sku, "subs", devPayload);
            if (subscribeBundle.getInt("RESPONSE_CODE") == 0) {
                PendingIntent pendingIntent = subscribeBundle.getParcelable("BUY_INTENT");
                if (pendingIntent != null) {
                    mContext.startIntentSenderForResult(pendingIntent.getIntentSender(), REQUEST_PURCHASE,
                            new Intent(), 0, 0, 0);
                }
            }
        } catch (RemoteException|IntentSender.SendIntentException e) {
            Log.e(LOG_TAG, e.getMessage());
        }
    }

    private void showSubscribeDialog() {
        class SubscribeListener implements DialogInterface.OnClickListener {
            public SubscribeListener(int defaultSelection) {
                this.selectSku(defaultSelection);
            }

            private String selectedSku;

            public void selectSku(int which) {
                if (which >= 0) {
                    selectedSku = SUBSCRIPTIONS[which];
                }
            }

            @Override
            public void onClick(DialogInterface dialog, int which) {
                subscribe(selectedSku);
            }
        }

        final int defaultSelectedItem = 0;
        final SubscribeListener listener = new SubscribeListener(defaultSelectedItem);
        String[] subscriptionNames = { mContext.getString(R.string.dialog_subscribe_month),
            mContext.getString(R.string.dialog_subscribe_year) };

        new AlertDialog.Builder(mContext)
                .setTitle(mDialogTitle)
                .setSingleChoiceItems(subscriptionNames, defaultSelectedItem,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                listener.selectSku(which);
                            }
                        })
                .setPositiveButton(mContext.getString(R.string.dialog_subscribe_button), listener)
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        if (mCallback != null) {
                            mCallback.onSubscribeResult(false);
                        }
                    }
                })
                .show();
    }

    public interface SubscriptionResult {
        void onSubscribeResult(boolean isSubscribed);
    }
}
