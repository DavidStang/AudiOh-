package life.lookup.audioh;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import life.lookup.audioh.utils.SubscriptionHelper;

public class WelcomeFragment extends Fragment {

    final static String LAYOUT_ID = "layoutId";

    public static WelcomeFragment newInstance(int layoutId) {
        WelcomeFragment pane = new WelcomeFragment();
        Bundle bundle = new Bundle();
        bundle.putInt(LAYOUT_ID, layoutId);
        pane.setArguments(bundle);
        return pane;
    }

    private SubscriptionHelper mSubscriptionHelper;

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mSubscriptionHelper != null)
            mSubscriptionHelper.destroy();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(getArguments().getInt(LAYOUT_ID, -1), container, false);

        Button button = (Button) view.findViewById(R.id.welcome_subscribe_button);
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mSubscriptionHelper != null)
                        mSubscriptionHelper.destroy();
                    mSubscriptionHelper = new SubscriptionHelper(getActivity(),
                            getString(R.string.dialog_subscribe_title2));
                }
            });
        }

        return view;
    }
}