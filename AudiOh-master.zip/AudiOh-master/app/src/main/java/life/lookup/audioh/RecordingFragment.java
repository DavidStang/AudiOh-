package life.lookup.audioh;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.media.AudioFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.annotation.RequiresPermission;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Toast;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import life.lookup.audioh.recording.AudioThreadStatusListener;
import life.lookup.audioh.recording.EncodingThread;
import life.lookup.audioh.recording.RecordingThread;
import life.lookup.audioh.utils.RawSoundFile;
import life.lookup.audioh.views.RealtimeWaveformView;

public class RecordingFragment extends Fragment {

    private RealtimeWaveformView mWaveformView;
    private Chronometer mChronometer;
    private Button mRecordButton;
    private Button mEditButton;
    private Button mRecordingListButton;
    private View mMain;

    private RecordingThread mRecordingThread;
    private EncodingThread mEncodingThread;
    private Location mLocation;
    private boolean mIsRecording = false;
    private static final int MAX_RECORDING_DURATION = 30 * 1000;
    private static final int REQUEST_RECORD_AUDIO = 13;
    private static final String LOG_TAG = RecordingFragment.class.getSimpleName();

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mLocation = getActivity().getIntent().getParcelableExtra(MainActivity.ARG_LOCATION);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_recording, container, false);

        mMain = view.findViewById(R.id.recording_main_layout);

        mRecordButton = (Button) view.findViewById(R.id.recordButton);
        mRecordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRecordClick();
            }
        });

        mEditButton = (Button) view.findViewById(R.id.editButton);
        mEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onEditClick();
            }
        });

        mRecordingListButton = (Button) view.findViewById(R.id.listButton);
        mRecordingListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startList = new Intent(getActivity(), RecordingsListActivity.class);
                startActivity(startList);
            }
        });

        mChronometer = (Chronometer) view.findViewById(R.id.chronometer);
        mChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                long elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
                if (elapsedMillis >= MAX_RECORDING_DURATION) {
                    stopRecording();
                }
            }
        });

        mWaveformView = (RealtimeWaveformView) view.findViewById(R.id.waveform);

        return view;
    }

    @Override
    public void onPause() {
        super.onPause();

        if (mIsRecording) {
            stopRecording();
        }
    }

    public void onRecordClick() {
        if (mIsRecording) {
            stopRecording();
        } else {
            if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.RECORD_AUDIO)
                    == PackageManager.PERMISSION_GRANTED) {
                startRecording();
            } else {
                requestMicrophonePermission();
            }
        }
    }

    public void onEditClick() {
        Uri recordingUri = mEncodingThread.getRecordingUri();
        if (recordingUri == null) {
            Log.e(LOG_TAG, "onEditClick. No item inserted?");
            return;
        }
        Intent startEdit = new Intent(getActivity(), EditActivity.class);
        startEdit.putExtra(PlaybackFragment.ARG_RECORDING_URI, recordingUri);
        startActivity(startEdit);
    }

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    private void startRecording() {
        Log.v(LOG_TAG, "Starting recording");

        startThreads();

        mIsRecording = true;

        mEditButton.setEnabled(false);
        mRecordButton.setText(getString(R.string.button_stopRecord));
    }

    private void stopRecording() {
        Log.v(LOG_TAG, "Stopping recording");

        mIsRecording = false;

        stopThreads();

        mChronometer.stop();
        mRecordButton.setText(getString(R.string.button_record));
    }

    private void startThreads() {
        BlockingQueue<short[]> data = new LinkedBlockingQueue<>();

        mRecordingThread = new RecordingThread(getActivity(), data, RawSoundFile.SAMPLING_RATE,
                AudioFormat.CHANNEL_IN_MONO, RawSoundFile.AUDIO_FORMAT, new AudioThreadStatusListener() {
            @Override
            public void onStarted() {
                mChronometer.setBase(SystemClock.elapsedRealtime());
                mChronometer.start();
            }

            @Override
            public void onFailure(String reason, Exception error) {
                RecordingFragment.this.onFailure(reason, error);
            }

            @Override
            public void onCompleted() {
            }
        });
        mEncodingThread = new EncodingThread(getActivity(), data, mLocation,
                new AudioThreadStatusListener() {
                    @Override
                    public void onStarted() {
                    }

                    @Override
                    public void onFailure(String reason, Exception error) {
                        RecordingFragment.this.onFailure(reason, error);
                    }

                    @Override
                    public void onCompleted() {
                        // Flip button
                        mEditButton.setEnabled(true);
                    }
                }, mWaveformView);
        new Thread(mRecordingThread).start();
        new Thread(mEncodingThread).start();
    }

    private void stopThreads() {
        mRecordingThread.stop();
    }

    private void onFailure(String reason, Exception error) {
        stopThreads();
        Toast toast = Toast.makeText(getActivity(), reason, Toast.LENGTH_LONG);
        toast.show();
    }

    private void requestMicrophonePermission() {
        Log.v(LOG_TAG, "Requesting permission");
        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
                Manifest.permission.RECORD_AUDIO)) {
            // Show dialog explaining why we need record audio
            Snackbar.make(mMain, "Microphone access is required in order to record birds",
                    Snackbar.LENGTH_INDEFINITE).setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    requestPermissions(new String[] {
                            Manifest.permission.RECORD_AUDIO }, REQUEST_RECORD_AUDIO);
                }
            }).show();
        } else {
            requestPermissions(new String[]{
                    Manifest.permission.RECORD_AUDIO}, REQUEST_RECORD_AUDIO);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_RECORD_AUDIO && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Log.v(LOG_TAG, "Record audio permission granted");
            startRecording();
        } else {
            Log.v(LOG_TAG, "Record audio permission denied");
        }
    }
}
