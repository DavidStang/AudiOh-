package life.lookup.audioh.utils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AudioUtils {
    public static byte[] createWAVHeader(int sampleRate, int numChannels, int numSamples) {
        byte[] header = new byte[46];
        int numBytesPerSample = 2 * numChannels;
        int offset = 0;
        int size;

        // set the RIFF chunk
        System.arraycopy(new byte[] {'R', 'I', 'F', 'F'}, 0, header, offset, 4);
        offset += 4;
        size = 36 + numSamples * numBytesPerSample;
        header[offset++] = (byte)(size & 0xFF);
        header[offset++] = (byte)((size >> 8) & 0xFF);
        header[offset++] = (byte)((size >> 16) & 0xFF);
        header[offset++] = (byte)((size >> 24) & 0xFF);
        System.arraycopy(new byte[] {'W', 'A', 'V', 'E'}, 0, header, offset, 4);
        offset += 4;

        // set the fmt chunk
        System.arraycopy(new byte[] {'f', 'm', 't', ' '}, 0, header, offset, 4);
        offset += 4;
        System.arraycopy(new byte[] {0x10, 0, 0, 0}, 0, header, offset, 4);  // chunk size = 16
        offset += 4;
        System.arraycopy(new byte[] {1, 0}, 0, header, offset, 2);  // format = 1 for PCM
        offset += 2;
        header[offset++] = (byte)(numChannels & 0xFF);
        header[offset++] = (byte)((numChannels >> 8) & 0xFF);
        header[offset++] = (byte)(sampleRate & 0xFF);
        header[offset++] = (byte)((sampleRate >> 8) & 0xFF);
        header[offset++] = (byte)((sampleRate >> 16) & 0xFF);
        header[offset++] = (byte)((sampleRate >> 24) & 0xFF);
        int byteRate = sampleRate * numBytesPerSample;
        header[offset++] = (byte)(byteRate & 0xFF);
        header[offset++] = (byte)((byteRate >> 8) & 0xFF);
        header[offset++] = (byte)((byteRate >> 16) & 0xFF);
        header[offset++] = (byte)((byteRate >> 24) & 0xFF);
        header[offset++] = (byte)(numBytesPerSample & 0xFF);
        header[offset++] = (byte)((numBytesPerSample >> 8) & 0xFF);
        System.arraycopy(new byte[] {0x10, 0}, 0, header, offset, 2);
        offset += 2;

        // set the beginning of the data chunk
        System.arraycopy(new byte[] {'d', 'a', 't', 'a'}, 0, header, offset, 4);
        offset += 4;
        size = numSamples * numBytesPerSample;
        header[offset++] = (byte)(size & 0xFF);
        header[offset++] = (byte)((size >> 8) & 0xFF);
        header[offset++] = (byte)((size >> 16) & 0xFF);
        header[offset] = (byte)((size >> 24) & 0xFF);

        return header;
    }

    public static int getAudioLength(long numSamples, int sampleRate) {
        return (int) (numSamples * 1000) / sampleRate;
    }

    public static byte[] encodeAudioFileToWave(RawSoundFile audioFile) {
        int numSamples = audioFile.getNumSamples();
        byte[] wavHeader = AudioUtils.createWAVHeader(audioFile.getSampleRate(),
                audioFile.getChannelsCount(), numSamples);
        byte[] data = new byte[wavHeader.length + (numSamples * 2)];
        System.arraycopy(wavHeader, 0, data, 0, wavHeader.length);
        short[] samples = new short[numSamples];
        audioFile.getSamples().get(samples);
        ByteBuffer buffer = ByteBuffer.wrap(data);
        buffer.position(wavHeader.length);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.asShortBuffer().put(samples);

        return data;
    }
}
